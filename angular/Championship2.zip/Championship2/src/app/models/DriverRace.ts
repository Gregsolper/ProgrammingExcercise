import { Time } from "@angular/common";
export class DriverRace {
    name : String ="";
    time : any;
    position : number=99;
}