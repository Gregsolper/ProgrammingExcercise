export class Driver {
    _id : any;
    picture : string ="";
    age : number= 20;
    name : string ="";
    team : string ="";
    gRanking : number=99;
}