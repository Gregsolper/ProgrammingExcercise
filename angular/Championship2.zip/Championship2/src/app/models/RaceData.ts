import { RaceDriver} from "./RaceDriver"
export class RaceData {
    name : String ="";
    RaceDriver : Array<RaceDriver> = [];
}