export class Option {
    id : String ="";
    name : String ="";
}