export class RaceDriver {
    _id : any;
    name : string ="";
    team : string ="";
    time : string = '';
    picture : string ="";
    timeCompare? : Date;
    position : number=99;
}